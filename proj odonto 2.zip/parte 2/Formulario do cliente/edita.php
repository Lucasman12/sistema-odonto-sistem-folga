<html>
<head>
    <title>Editar</title>
    
	

	
			<link rel="stylesheet" type="text/css" href="meuestilo.css">

	<link rel="stylesheet" href="css/style.css">


   <div class="site-section-cover img-bg-section" style="background-image: url('images/person-transparent-2.png'); " data-aos="fade">

<div class="logo">
   <div class="symbol"></div>
   <div class="nome">System</div>
   <div class="slogan">Odontologia</div>
</div>



</div>

       <style type="text/css">

input[type=text]{   
    border-radius:4px;
    -moz-border-radius:4px;
    -webkit-border-radius:4px;
    box-shadow: 1px 1px 2px #333333;    
    -moz-box-shadow: 1px 1px 2px #333333;
    -webkit-box-shadow: 1px 1px 2px #333333;
    background: #00; 
    border:1px solid ;
    width:150px
}
 
textarea{
    border: 1px solid #000000;
    background: #00  ;
    width:150px;
    height:100px;
    border-radius:4px;
    -moz-border-radius:4px;
    -webkit-border-radius:4px;
    box-shadow: 1px 1px 2px #333333;    
    -moz-box-shadow: 1px 1px 2px #333333;
    -webkit-box-shadow: 1px 1px 2px #333333;
}
 
input[type=text]:hover, textarea:hover{ 
         background: #ffffff; border:1px solid #990000;
}
 
input[type=submit]{
        background:#006699;
        color:#ffffff;
}

    </style>
	
	
	
</head>
		<link rel="stylesheet" type="text/css" href="meuestilo.css">

    <body bgcolor="#8FBC8F">
	

	       
</head>
    <body bgcolor="#8FBC8F">
	
	        <?php 
				
            //Recebe os dados a serem editados
            $id = filter_input(INPUT_POST, 'id');
            $pago = filter_input(INPUT_POST, 'pago');
            $nome = filter_input(INPUT_POST, 'nome');
            $cpf = filter_input(INPUT_POST, 'cpf');
		     $email = filter_input(INPUT_POST, 'email');
			  $telefone = filter_input(INPUT_POST, 'telefone');
			   $valor = filter_input(INPUT_POST, 'valor');
			    $data = filter_input(INPUT_POST, 'data');

		?>
		<br>
		<br>
        <h2><font color="black">Alteracao de Dados</h2>

        <form action="Salva.php" method="post">
            <!-- Jogamos os valores a serem editados dentro dos inputs no campo value -->
            <input type="hidden" name="id" value="<?php echo $id; ?>">
            Pagamento<br><input type="text" name="pago" value="<?php echo $pago; ?>">
			<br>
            Nome   &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Cpf
			<br><input type="text" name="nome" value="<?php echo $nome; ?>">
			
			 <input type="text" name="cpf" value="<?php echo $cpf; ?>">
			 <br>
			 Email     &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Telefone 
			 <br> <input type="text" name="email" value="<?php echo $email; ?>"> 
			 
			   <input type="text" name="telefone" value="<?php echo $telefone; ?>">
			   <br>
				Valor<br>  <input type="text" name="valor" value="<?php echo $valor; ?>">
				<br>
				 Data <br><input type="text" name="data" value="<?php echo $data; ?>">
				 <br>
				 <br>
            <button class="button">Salvar alteracoes</button>			
			

        </form>
    </body>
</html>