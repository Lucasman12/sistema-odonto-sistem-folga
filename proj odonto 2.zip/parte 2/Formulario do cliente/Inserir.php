<html>
<head>
    <title>Pessoas</title>
	</head>
	<meta charset="UTF-8">
		
		<link rel="stylesheet" type="text/css" href="meuestilo.css">

	<!--<div class="logo">
   <div class="symbol"></div>
   <div class="nome">System</div>
   <div class="slogan">Odontologia</div>
</div>

<body onload='window.history.back();'>!-->




<body bgcolor="#8FBC8F">




<?php 

include "conect.php";

$pago= $_POST['pago'];
$nome= $_POST['nome'];
$cpf= $_POST['cpf'];
$email= $_POST['email'];
$telefone= $_POST['telefone'];
$valor= $_POST['valor'];
$data=$_POST['data'];

echo "<br>";
echo "<h4>Pago:".$pago."<br>";
echo "<br>";
echo "<br>Nome:".$nome."<br>";
echo "<br>";
echo "<br>CPF:".$cpf."<br>";
echo "<br>";
echo "<br>Email:".$email."<br>";
echo "<br>";
echo "<br>Telefone:".$telefone."<br>";
echo "<br>";
echo "<br>Valor:".$valor."<br>";
echo "<br>";
echo "<br>Data:".$data."</center><br>";

echo "<br>";
if($pago !="" && $nome !=""  && $cpf !=""  &&  $email !="" && $telefone !="" && $valor !="" && $data !=""  ){

mysqli_query($link, "INSERT INTO pagamento(pago,nome, cpf, email, telefone, valor, data)

VALUES('$pago','$nome', '$cpf' ,'$email','$telefone','$valor','$data' )");

}else{

echo "<center><h3>Dados inserido com sucesso<h3></center>";


}

//echo "<center><a href=http://localhost/Crud%20php/inserir.php  button>Imprimir</center></a></button>";
?>

<br>
<br>

<Button class="button"><script>var pfHeaderImgUrl = '';var pfHeaderTagline = '';var pfdisableClickToDel = 0;var pfHideImages = 0;var pfImageDisplayStyle = 'block';var pfDisablePDF = 0;var pfDisableEmail = 0;var pfDisablePrint = 0;var pfCustomCSS = '';var pfBtVersion='1';(function(){var js, pf;pf = document.createElement('script');pf.type = 'text/javascript';if('https:' == document.location.protocol){js='https://pf-cdn.printfriendly.com/ssl/main.js'}else{js='http://cdn.printfriendly.com/printfriendly.js'}pf.src=js;document.getElementsByTagName('head')[0].appendChild(pf)})();</script><a href="" style="color:#6D9F00;text-decoration:none;" class="printfriendly" onclick="window.print();return false;" title="Email"><img style="border:none;-webkit-box-shadow:none;box-shadow:none;" src="" alt=""/><font color="black">Email</button></a>



<a href="http://localhost/System%20odonto/Modo%20de%20pagamento/cadastro.html" class="button">Voltar_____</a>
     	
<br>
<br>
<br>
<br>
<br>
<br>
</center>
</body>
</html>

<html>
<head>
<title></title>
</head>
<body>
<h5>Rua XX , S/N </h5>
<h5>Bairro XX , Cidade : Mogi das Cruzes -SP </h5>

</html>
</body>