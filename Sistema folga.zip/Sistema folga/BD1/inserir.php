<html>
<head>

<meta charset="UTF-8">
<!--<style type="text/css">


</style>!-->	

    <title>Empresa</title>
    	<link href="estilos_impressao.css" rel="stylesheet" type="text/css" media="print">
	<style type="text/css">
     
				.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 5px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 12px;
  margin: 4px 2px;
  cursor: pointer;
}

	
				table {
  border: 1px solid #1C6EA4;
  background-color: #EEEEEE;
  width: 100%;
  text-align: left;
  border-collapse: collapse;
}
table.blueTable td, table.blueTable th {
  border: 1px solid #AAAAAA;
  padding: 3px 2px;
}
table.blueTable tbody td {
  font-size: 13px;
}
table.blueTable tr:nth-child(even) {
  background: #D0E4F5;
}
table.blueTable thead {
  background: #1C6EA4;
  background: -moz-linear-gradient(top, #5592bb 0%, #327cad 66%, #1C6EA4 100%);
  background: -webkit-linear-gradient(top, #5592bb 0%, #327cad 66%, #1C6EA4 100%);
  background: linear-gradient(to bottom, #5592bb 0%, #327cad 66%, #1C6EA4 100%);
  border-bottom: 2px solid #444444;
}
table.blueTable thead th {
  font-size: 15px;
  font-weight: bold;
  color: #FFFFFF;
  border-left: 2px solid #D0E4F5;
}
table.blueTable thead th:first-child {
  border-left: none;
}

table.blueTable tfoot {
  font-size: 14px;
  font-weight: bold;
  color: #FFFFFF;
  background: #D0E4F5;
  background: -moz-linear-gradient(top, #dcebf7 0%, #d4e6f6 66%, #D0E4F5 100%);
  background: -webkit-linear-gradient(top, #dcebf7 0%, #d4e6f6 66%, #D0E4F5 100%);
  background: linear-gradient(to bottom, #dcebf7 0%, #d4e6f6 66%, #D0E4F5 100%);
  border-top: 2px solid #444444;
}
table.blueTable tfoot td {
  font-size: 14px;
}
table.blueTable tfoot .links {
  text-align: right;
}
table.blueTable tfoot .links a{
  display: inline-block;
  background: #1C6EA4;
  color: #FFFFFF;
  padding: 2px 8px;
  border-radius: 5px;
}
		
    </style>
	

<body bgcolor="#EEE9E9">
<?php

include "conect.php";

$colaborador = $_POST['colaborador'];
$folga= $_POST['folga'];
$data= $_POST['data'];
$data2= $_POST['data2'];
$data3= $_POST['data3'];
$data4= $_POST['data4'];
$horario= $_POST['horario'];
$supervisor= $_POST['supervisor'];

echo "<br>";
echo "<br>";
echo "Colaborador.:".$colaborador."<br>";
echo "<br>"; 
echo "Folga.:".$folga."<br>";
echo "<br>"; 
echo "Data.:".$data."<br>";
echo "<br>"; 
echo "Data.:".$data2."<br>";
echo "<br>"; 
echo "Data.:".$data3."<br>";
echo "<br>"; 
echo "Data.:".$data4."<br>";
echo "<br>"; 
echo "Horario.:".$horario."<br>";
echo "<br>";
echo "Supervisor.:".$supervisor."<br>";

echo "<br>";
if($colaborador !="" &&  $folga !=""  && $data !="" &&  $data2 !="" && $data3 !=""  && $data4 !=""   &&  $horario !="" &&  $supervisor !=""){

mysqli_query($link, "INSERT INTO folga(colaborador, folga, data, data2, data3, data4,  horario,supervisor)
VALUES ('$colaborador','$folga','$data', '$data2', '$data3', '$data4', '$horario', '$supervisor' )");

}else{

echo "Dados cadastrados com exito!";


   
}

echo "<br>";
		echo "<br>";
		
		
		echo "<a href=http://localhost/Sistema%20folga/BD1/cadastro.html ><button class='button'>Voltar</button></h1> <br></a>" ;
	 
        
?>

<Button class="button"><script>var pfHeaderImgUrl = '';var pfHeaderTagline = '';var pfdisableClickToDel = 0;var pfHideImages = 0;var pfImageDisplayStyle = 'block';var pfDisablePDF = 0;var pfDisableEmail = 0;var pfDisablePrint = 0;var pfCustomCSS = '';var pfBtVersion='1';(function(){var js, pf;pf = document.createElement('script');pf.type = 'text/javascript';if('https:' == document.location.protocol){js='https://pf-cdn.printfriendly.com/ssl/main.js'}else{js='http://cdn.printfriendly.com/printfriendly.js'}pf.src=js;document.getElementsByTagName('head')[0].appendChild(pf)})();</script><a href="" style="color:#6D9F00;text-decoration:none;" class="printfriendly" onclick="window.print();return false;" title="Email"><img style="border:none;-webkit-box-shadow:none;box-shadow:none;" src="" alt=""/><font color="black">Email</button></a>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<h5><center><font size="2">Todos direitos reservados a Valdeir Lucas</center></h5>

</html>
</body>


