<html>
<head>

<meta charset="UTF-8">
<!--<style type="text/css">


</style>!-->	
	<link rel="stylesheet" type="text/css" href="meuestilo.css">

    <title>Pessoas</title>
    	<link href="estilos_impressao.css" rel="stylesheet" type="text/css" media="print">
	<style type="text/css">
        *{
            margin: 15;
            padding: 0 ;
        }
        table{
            border: 1px solid gray;
            padding: 1em
        }
        td{
            border: 1px solid lightgray;
            font-size: 1em;
            padding: 0px
        }
        button{
            padding: 5px
			
        }
	
				table {
  border: 1px solid #1C6EA4;
  background-color: #EEEEEE;
  width: 100%;
  text-align: left;
  border-collapse: collapse;
}
table.blueTable td, table.blueTable th {
  border: 1px solid #AAAAAA;
  padding: 3px 2px;
}
table.blueTable tbody td {
  font-size: 13px;
}
table.blueTable tr:nth-child(even) {
  background: #D0E4F5;
}
table.blueTable thead {
  background: #1C6EA4;
  background: -moz-linear-gradient(top, #5592bb 0%, #327cad 66%, #1C6EA4 100%);
  background: -webkit-linear-gradient(top, #5592bb 0%, #327cad 66%, #1C6EA4 100%);
  background: linear-gradient(to bottom, #5592bb 0%, #327cad 66%, #1C6EA4 100%);
  border-bottom: 2px solid #444444;
}
table.blueTable thead th {
  font-size: 15px;
  font-weight: bold;
  color: #FFFFFF;
  border-left: 2px solid #D0E4F5;
}
table.blueTable thead th:first-child {
  border-left: none;
}

table.blueTable tfoot {
  font-size: 14px;
  font-weight: bold;
  color: #FFFFFF;
  background: #D0E4F5;
  background: -moz-linear-gradient(top, #dcebf7 0%, #d4e6f6 66%, #D0E4F5 100%);
  background: -webkit-linear-gradient(top, #dcebf7 0%, #d4e6f6 66%, #D0E4F5 100%);
  background: linear-gradient(to bottom, #dcebf7 0%, #d4e6f6 66%, #D0E4F5 100%);
  border-top: 2px solid #444444;
}
table.blueTable tfoot td {
  font-size: 14px;
}
table.blueTable tfoot .links {
  text-align: right;
}
table.blueTable tfoot .links a{
  display: inline-block;
  background: #1C6EA4;
  color: #FFFFFF;
  padding: 2px 8px;
  border-radius: 5px;
}
		
    </style>
	
	
</head>
<body bgcolor="#EEE9E9">
    <?php 
        //Área de notificações

        //Se existe a variável remocao, então
        if( isset($_GET['remocao'])){
            //Se remoção tem true, os dados foram removidos
            if( $_GET['remocao'] == "true" ){
				echo "<br>";
				echo "<br>";
                echo "<p><h1><center>Os dados foram removidos.</center></h1></p>";            
            }else{
                echo "<p>Não foi possivel remover os dados.</p>";
            }
        } 
        //Se existe a variável alteração, então
        if( isset($_GET['alteracao']) ){
            //Se alteracao tem true, os dados foram alterados
            if( $_GET['alteracao'] == "true" ){
                echo "<p>Os dados foram alterados.</p>";            
            }else{
                echo "<p>Não foi possivel alterar os dados.</p>";
            }/*dados*/
        } 
    ?>
    <table>
	
       <table>
	
        <caption><h1>Pessoas</h1></caption>
       <tr><td><font color  ="#" >ID</color></td><td><font color  ="#" > COLABORADOR</color></td><td><font color="red"> FOLGA</font></td><td><font color  ="#" >DATA</font></td><td><font color  ="#" >DATA</font></td><td><font color  ="#" >DATA</font></td><td><font color  ="#" >DATA</font></td><td><font color  ="green" >HORARIO</font></td><td><font color  ="#" >SUPERVISOR</font></td><td></font></td><td><font color  ="#" >REMOVER</font></td></tr>
                </center>
		<br/> <?php 
            //Estabelece a conexao com o mysql
            $conexao = mysqli_connect("localhost","root","root","descanso");
            if( !$conexao ){
                echo "Ops.. Erro na conexão.";
                exit;
            }
            //Carrega os dados
            $sql = "SELECT * FROM folga";
            $consulta = mysqli_query($conexao, $sql);
            if(!$consulta ){
                echo "Erro ao realizar consulta. Tente outra vez.";
                exit;
            }
            //se tudo deu certo, exibe os dados
            while( $dados = mysqli_fetch_assoc($consulta) ){
                            
			    echo "<tr>";
				echo "<td>" .$dados['id']."</td>";
				echo "<td>" .$dados['colaborador']."</td>";
                echo "<td>" .$dados['folga']."</td>";
                echo "<td>" .$dados['data']."</td>";
				echo "<td>" .$dados['data2']."</td>";
                echo "<td>" .$dados['data3']."</td>";
                echo "<td>" .$dados['data4']."</td>";
	 			echo "<td>" .$dados['horario']."</td>";
				echo "<td>" .$dados['supervisor']."</td>";
				
				
				// Cria um formulário para enviar os dados para a página de edição 
                // Colocamos os dados dentro input hidden
               
     		  		
                        		
                          	
                echo "<td>"; 
			    echo  "<font color  =White >";
				echo "<form action='edita.php' method='post'>";
				echo "<input name='id' type='hidden' value='" .$dados['id']. "'>";
                echo "<input name='colaborador' type='hidden' value='".$dados['colaborador']. "'>";
                echo "<input name='folga' type='hidden' value='".$dados['folga']. "'>";  
                echo "<input name='data' type='hidden' value='".$dados['data']."'>";
                echo "<input name='data2' type='hidden' value='".$dados['data2']."'>"; 				
                echo "<input name='data3' type='hidden' value='".$dados['data3']."'>"; 				
                echo "<input name='data4' type='hidden' value='".$dados['data4']."'>"; 				
				echo "<input name='horario' type='hidden' value='".$dados['horario']."'>"; 				
                echo "<input name='supervisor' type='hidden' value='".$dados['supervisor']."'>"; 				
               echo "<button>Editar</button>";
           	    echo "</form>";
                echo "</td>";
                echo "</font>";
				
				
                // Cria um formulário para remover os dados 
                // Colocamos o id dos dados a serem removidos dentro do input hidden
                echo "<td>";
				echo "<form action='remove.php' method='post'>";
                echo "<input name='id' type='hidden' value='" .$dados['id']. "'>";
                echo "<button>Remover</button>";
				echo "<td>";
				//echo "<button>Imprimir</button>";
                echo "</form>";
                echo "</td>";
                echo "</tr>";
								
			};
            
        echo "<br>";
		echo "<br>";
		echo "<a href=http://localhost/Sistema%20folga/index/ ><button class='button'>Voltar para o menu inicial </button></h1> <br></a>" ;
	 
		?>
		
    </table>
</body>
</html>
