<?php
$host= '';
$user="root";
$pass="root";
$banco="descanso";
$link = mysqli_connect($host, $user, $pass, $banco);

if(mysqli_errno($link)){

echo "Ops..erro!";

}else{

}
 
?>

