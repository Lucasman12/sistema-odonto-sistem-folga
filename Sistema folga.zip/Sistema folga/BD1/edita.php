<html>
<head>

<meta charset="UTF-8">
<!--<style type="text/css">


</style>!-->	

    <title>Empresa</title>
    	<link href="estilos_impressao.css" rel="stylesheet" type="text/css" media="print">
	<style type="text/css">
     
				.button {
  background-color: #4CAF50;
  border: none;
  color: white;
  padding: 5px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 12px;
  margin: 4px 2px;
  cursor: pointer;
}
	
    </style>
	

<body bgcolor="#EEE9E9"> 


<?php

$id=filter_input(INPUT_POST, 'id');
$colaborador= filter_input(INPUT_POST, "colaborador"); 
$folga=filter_input(INPUT_POST, "folga");
$data=filter_input(INPUT_POST, "data");
$data2=filter_input(INPUT_POST, "data2");
$data3=filter_input(INPUT_POST, "data3");
$data4=filter_input(INPUT_POST, "data4");
$horario=filter_input(INPUT_POST, "horario");
$supervisor=filter_input(INPUT_POST, "supervisor");

?>

<form action="salva.php"  method="post">

<input type="hidden"  name="id"  value="<?php echo $id;?>"><br>
<br>
Colaborador:<br> <input type="colaborador"  name="colaborador" value="<?php echo $colaborador; ?>"><br> 
<br> 
Folga: <br> <input type="folga"  name="folga" value="<?php echo $folga; ?>"><br> 
<br> 
Data: <br> <input type="data"  name="data" value="<?php echo $data; ?>"><br> 
<br> 

Data: <br> <input type="data2"  name="data2" value="<?php echo $data2; ?>"><br> 
<br> 
Data: <br> <input type="data3"  name="data3" value="<?php echo $data3; ?>"><br> 
<br> 
Data: <br> <input type="data4"  name="data4" value="<?php echo $data4; ?>"><br> 
<br> 
Horario: <br> <input type="horario"  name="horario" value="<?php echo $horario; ?>"><br> 
<br> 
<br> 
Supervisor: <br> <input type="supervisor"  name="supervisor" value="<?php echo $supervisor; ?>"><br> 
<br> 
<Button class="button">Alterar</Button>
</form>
</html>
</body>

