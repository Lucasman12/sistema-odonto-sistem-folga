<html>
<head>
    <title>Pessoas</title>
	</head>
	<meta charset="UTF-8">
		
		<link rel="stylesheet" type="text/css" href="meuestilo.css">



<body bgcolor="#8FBC8F">




<?php 

include "conect.php";

$nome= $_POST['nome'];
$cpf= $_POST['cpf'];
$data= $_POST['data'];
$comentario=$_POST['comentario'];

echo "<br>";
echo "<h4>Nome:".$nome."<br>";
echo "<br>";
echo "<br>Cpf:".$cpf."<br>";
echo "<br>";
echo "<br>data:".$data."<br>";
echo "<br>";
echo "<br>Comentario:".$comentario."<br>";
echo "<br>";


if($nome !="" &&   $cpf !="" &&   $data !=""  && $comentario !=""   ){

mysqli_query($link, "INSERT INTO agenda(nome, cpf ,data,comentario)

VALUES('$nome','$cpf','$data','$comentario' )");

}else{

echo "<h3>Dados inserido com sucesso<h3>";

echo "<br>";
echo "<br>";
echo "<br>";
echo "<br>";
echo "<br>";
echo "<br>";
echo "<br>";
echo "<br>";

}

//echo "<center><a href=http://localhost/Crud%20php/inserir.php  button>Imprimir</center></a></button>";
?>
<br>
<br>
<a href="http://localhost/System%20odonto/agenda/cadastro.html" class="button">Voltar_____</a>



</body>
</html>
