<html>
<head>
    <title>Editar</title>
    
	

	
			<link rel="stylesheet" type="text/css" href="meuestilo.css">

	<link rel="stylesheet" href="css/style.css">


   <div class="site-section-cover img-bg-section" style="background-image: url('images/person-transparent-2.png'); " data-aos="fade">

<div class="logo">
   <div class="symbol"></div>
   <div class="nome">System</div>
   <div class="slogan">Odontologia</div>
</div>



</div>

       <style type="text/css">

input[type=text]{   
    border-radius:4px;
    -moz-border-radius:4px;
    -webkit-border-radius:4px;
    box-shadow: 1px 1px 2px #333333;    
    -moz-box-shadow: 1px 1px 2px #333333;
    -webkit-box-shadow: 1px 1px 2px #333333;
    background: #00; 
    border:1px solid ;
    width:150px
}
 
textarea{
    border: 1px solid #000000;
    background: #00  ;
    width:150px;
    height:100px;
    border-radius:4px;
    -moz-border-radius:4px;
    -webkit-border-radius:4px;
    box-shadow: 1px 1px 2px #333333;    
    -moz-box-shadow: 1px 1px 2px #333333;
    -webkit-box-shadow: 1px 1px 2px #333333;
}
 
input[type=text]:hover, textarea:hover{ 
         background: #ffffff; border:1px solid #990000;
}
 
input[type=submit]{
        background:#006699;
        color:#ffffff;
}

    </style>
	
	
	
</head>
		<link rel="stylesheet" type="text/css" href="meuestilo.css">

    <body bgcolor="#8FBC8F">
	

	       
</head>

    <body bgcolor="#8FBC8F">
	

			
		<link rel="stylesheet" type="text/css" href="meuestilo.css">

   <!-- <div class="site-section-cover img-bg-section" style="background-image: url('images/person-transparent-2.png'); " data-aos="fade">
</div>!-->
	
        <?php 
		
		
            //Recebe os dados a serem editados
            $id = filter_input(INPUT_POST, 'id');
            $nome = filter_input(INPUT_POST, 'nome');
            $cpf = filter_input(INPUT_POST, 'cpf');
		     $data = filter_input(INPUT_POST, 'data');
            $comentario = filter_input(INPUT_POST, 'comentario');

		?>
		<br>
		<br>
        <h2><font color="black">Alteracao de Dados</h2>
	   <br>
		<br>
        <form action="Salva.php" method="post">
            <!-- Jogamos os valores a serem editados dentro dos inputs no campo value -->
            <input type="hidden" name="id" value="<?php echo $id; ?>">
           Nome: <br><input type="text" name="nome" value="<?php echo $nome; ?>"></br>
		   <br>
           Cpf: <br><input type="cpf" name="cpf" value="<?php echo $cpf; ?>"></br>
		   <br>
		   
           Data: <br><input type="data" name="data" value="<?php echo $data; ?>"></br>
		   <br>
			Obs:<br><textarea name="comentario" id="comentario" rows=5    cols=35 value="<?php echo $comentario;?>"></textarea> </br>
			 <input type="submit" value="Salvar alteracoes"></center>
			
			<center>

        </form>
    </body>
</html>