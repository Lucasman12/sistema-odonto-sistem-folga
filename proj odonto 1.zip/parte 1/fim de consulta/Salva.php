<?php 

    include "edita.php";
    //Recebe os dados com as alterações feitas
    $id = filter_input(INPUT_POST, 'id');
    $novonome = filter_input(INPUT_POST, 'nome');
	$novocpf = filter_input(INPUT_POST, 'cpf');
    $novodata = filter_input(INPUT_POST, 'data');

	
    //Estabelece a conexão com o mysql
    $conexao = mysqli_connect("localhost","root","root","bd1");
    if( !$conexao ){
        header("Location:exibe.php?alteracao=false");
        exit;
    }
    //Executa a atualização no banco de dados
    $sql = "UPDATE fconsulta SET nome='" .$novonome. "', cpf='".$novocpf."'  ,data='" .$novodata. "'  WHERE id=".$id;
    $update = mysqli_query($conexao, $sql);

    //Se não deu certo, redireciona pra exibe.php com alteracao igual a false
    if( !$update ){
        header("Location:exibe.php?alteracao=false");
        exit;
    }

    //se tudo deu certo, redireciona pra exibe.php com alteracao igual a true
    header("Location:exibe.php?alteracao=true");
?>
 