<?php

$hostname = 'localhost';
$username = 'root';
$password = 'root';
$database = 'site';
$link= mysql_connect($hostname,$username, $password, $database); 


if (mysql_errno($link)){
	
	echo "Dados cadastro com exito!";
	
    }else{
		
	}
?>